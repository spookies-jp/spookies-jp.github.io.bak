//
//  SPKReversedTableView.h
//
//  Copyright (c) 2011 Spookies Co.,ltd. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SPKReversedTableView : UITableView

@end
