//
//  SPKReversedTableView.m
//
//  Copyright (c) 2011 Spookies Co.,ltd. All rights reserved.
//

#import "SPKReversedTableView.h"

@interface SPKReversedTableView () {
    UIEdgeInsets _normalScrollIndicatorInsets;
}

- (void)commonInit;

@end


@implementation SPKReversedTableView

- (id)initWithFrame:(CGRect)frame {
    self = [super initWithFrame:frame];
    if (self) {
        [self commonInit];
    }
    return self;
}

- (id)initWithFrame:(CGRect)frame style:(UITableViewStyle)style {
    self = [super initWithFrame:frame style:style];
    if (self) {
        [self commonInit];
    }
    return self;
}

- (id)initWithCoder:(NSCoder*)decoder {
    self = [super initWithCoder:decoder];
    if (self) {
        [self commonInit];
    }
    return self;
}

- (void)commonInit {
    self.transform = CGAffineTransformMakeRotation(M_PI);
    _normalScrollIndicatorInsets = UIEdgeInsetsZero;
}

- (void)setFrame:(CGRect)frame {
    [super setFrame:frame];
    self.scrollIndicatorInsets = _normalScrollIndicatorInsets;
}

- (UIEdgeInsets)scrollIndicatorInsets {
    return _normalScrollIndicatorInsets;
}

- (void)setScrollIndicatorInsets:(UIEdgeInsets)scrollIndicatorInsets {
    _normalScrollIndicatorInsets  = scrollIndicatorInsets;
    
    static CGFloat innerOffset = 9.0;
    
    UIEdgeInsets transposedInsets = UIEdgeInsetsMake(
        scrollIndicatorInsets.bottom,
        self.bounds.size.width - innerOffset - scrollIndicatorInsets.left,
        scrollIndicatorInsets.top,
        self.bounds.size.width - innerOffset - scrollIndicatorInsets.right
    );
    super.scrollIndicatorInsets = transposedInsets;
}

@end
