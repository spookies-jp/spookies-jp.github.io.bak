//
//  SPKReversedTableViewCell.m
//
//  Copyright (c) 2011 Spookies Co.,ltd. All rights reserved.
//

#import "SPKReversedTableViewCell.h"

@interface SPKReversedTableViewCell ()

- (void)commonInit;

@end


@implementation SPKReversedTableViewCell

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString*)reuseIdentifier {
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        [self commonInit];
    }
    return self;
}

- (id)initWithCoder:(NSCoder*)decoder {
    self = [super initWithCoder:decoder];
    if (self) {
        [self commonInit];
    }
    return self;
}

- (void)commonInit {
    self.transform = CGAffineTransformMakeRotation(-M_PI);
}

@end
